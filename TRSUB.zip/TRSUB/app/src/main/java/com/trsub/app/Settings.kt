package com.trsub.app

import android.content.Context

/** إعدادات التطبيق المحفوظة على الهاتف. */
class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("trsub", Context.MODE_PRIVATE)

    var key: String
        get() = p.getString("key", "") ?: ""
        set(v) { p.edit().putString("key", v).apply() }

    var url: String
        get() = p.getString("url", DEFAULT_URL) ?: DEFAULT_URL
        set(v) { p.edit().putString("url", v).apply() }

    var whisperModel: String
        get() = p.getString("whisper", DEFAULT_WHISPER) ?: DEFAULT_WHISPER
        set(v) { p.edit().putString("whisper", v).apply() }

    var llmModel: String
        get() = p.getString("llm", DEFAULT_LLM) ?: DEFAULT_LLM
        set(v) { p.edit().putString("llm", v).apply() }

    var smart: Boolean
        get() = p.getBoolean("smart", true)
        set(v) { p.edit().putBoolean("smart", v).apply() }

    var autoPause: Boolean
        get() = p.getBoolean("autoPause", true)
        set(v) { p.edit().putBoolean("autoPause", v).apply() }

    var bg: Boolean
        get() = p.getBoolean("bg", true)
        set(v) { p.edit().putBoolean("bg", v).apply() }

    var fontSize: Float
        get() = p.getFloat("font", 20f)
        set(v) { p.edit().putFloat("font", v).apply() }

    /** إزاحة التوقيت بالثواني: موجب = تظهر الترجمة أبكر. */
    var shift: Float
        get() = p.getFloat("shift", 0f)
        set(v) { p.edit().putFloat("shift", v).apply() }

    var lang: String
        get() = p.getString("lang", "auto") ?: "auto"
        set(v) { p.edit().putString("lang", v).apply() }

    companion object {
        const val DEFAULT_URL = "https://api.groq.com/openai/v1"
        const val DEFAULT_WHISPER = "whisper-large-v3-turbo"
        const val DEFAULT_LLM = "llama-3.3-70b-versatile"
    }
}
