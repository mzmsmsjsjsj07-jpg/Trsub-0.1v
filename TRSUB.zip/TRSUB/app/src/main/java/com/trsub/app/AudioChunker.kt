package com.trsub.app

import android.content.Context
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.net.Uri
import android.os.Build
import java.io.File
import java.nio.ByteBuffer

class ChunkAudio(val file: File, val baseSec: Double, val mime: String)

/** يقتطع جزءاً من المسار الصوتي للفيديو إلى ملف صغير بدون إعادة ترميز. */
object AudioChunker {

    /**
     * يرجع الملف + زمن أول عينة فيه (بالثواني، على خط زمن الفيديو)،
     * أو null إذا لم يوجد صوت في هذا الجزء.
     */
    fun extract(ctx: Context, uri: Uri, startUs: Long, endUs: Long, dir: File, name: String): ChunkAudio? {
        val ex = MediaExtractor()
        var muxer: MediaMuxer? = null
        var started = false
        var out: File? = null
        var result: ChunkAudio? = null
        try {
            ex.setDataSource(ctx, uri, null)
            var track = -1
            for (i in 0 until ex.trackCount) {
                val m = ex.getTrackFormat(i).getString(MediaFormat.KEY_MIME) ?: continue
                if (m.startsWith("audio/")) { track = i; break }
            }
            if (track < 0) throw IllegalStateException("لا يوجد مسار صوتي في الفيديو")
            val fmt = ex.getTrackFormat(track)
            val mime = fmt.getString(MediaFormat.KEY_MIME) ?: ""
            val ogg = (mime == "audio/opus" || mime == "audio/vorbis") && Build.VERSION.SDK_INT >= 29

            ex.selectTrack(track)
            ex.seekTo(startUs, MediaExtractor.SEEK_TO_PREVIOUS_SYNC)

            val f = File(dir, name + if (ogg) ".ogg" else ".m4a")
            out = f
            val mx = MediaMuxer(
                f.absolutePath,
                if (ogg) MediaMuxer.OutputFormat.MUXER_OUTPUT_OGG else MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4
            )
            muxer = mx
            val dst = try {
                val d = mx.addTrack(fmt)
                mx.start()
                started = true
                d
            } catch (e: Exception) {
                throw IllegalStateException("صيغة الصوت غير مدعومة ($mime)")
            }

            val buf = ByteBuffer.allocate(1 shl 20)
            val info = MediaCodec.BufferInfo()
            var base = -1L
            var written = 0
            while (true) {
                buf.clear()
                val size = ex.readSampleData(buf, 0)
                if (size < 0) break
                val t = ex.sampleTime
                if (t >= endUs) break
                if (base < 0) base = t
                info.set(0, size, t - base, ex.sampleFlags)
                mx.writeSampleData(dst, buf, info)
                written++
                ex.advance()
            }
            if (written > 0) {
                result = ChunkAudio(f, base / 1_000_000.0, if (ogg) "audio/ogg" else "audio/mp4")
            }
        } catch (e: Exception) {
            out?.delete()
            throw e
        } finally {
            try { if (started) muxer?.stop() } catch (_: Exception) {}
            try { muxer?.release() } catch (_: Exception) {}
            ex.release()
        }
        if (result == null) out?.delete()
        return result
    }
}
