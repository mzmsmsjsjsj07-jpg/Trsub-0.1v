package com.trsub.app

import kotlinx.coroutines.delay
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/** ترجمة ذكية تفهم السياق عبر نموذج لغوي (متوافق مع OpenAI، مثل Groq). */
object LlmTranslator {

    private const val SYSTEM =
        "You are a professional subtitle translator for anime, cartoons and movies. " +
        "Translate each dialogue line into natural, clear Modern Standard Arabic suitable for on-screen subtitles: " +
        "concise, faithful to the meaning, tone and emotion, never word-for-word. " +
        "Use previous_lines_for_context_only to work out who is speaking, omitted subjects (very common in Japanese), " +
        "pronouns, honorifics, idioms and jokes, but do not translate those previous lines. " +
        "Keep character names consistent and write them in Arabic letters. " +
        "Consecutive lines may be fragments of one sentence, so keep each translation natural and consistent with its neighbors. " +
        "If a line is only a sound effect, filler or music, return an empty string for it. " +
        "Reply with JSON only, in the form {\"translations\": [...]}, containing exactly as many strings " +
        "as lines_to_translate, in the same order."

    suspend fun translate(
        http: OkHttpClient, baseUrl: String, model: String, key: String,
        sourceLang: String, lines: List<String>, context: List<String>
    ): List<String> {
        val user = JSONObject()
            .put("source_language", sourceLang)
            .put("previous_lines_for_context_only", JSONArray(context))
            .put("lines_to_translate", JSONArray(lines))

        val bodyJson = JSONObject()
            .put("model", model)
            .put("temperature", 0.2)
            .put("response_format", JSONObject().put("type", "json_object"))
            .put(
                "messages", JSONArray()
                    .put(JSONObject().put("role", "system").put("content", SYSTEM))
                    .put(JSONObject().put("role", "user").put("content", user.toString()))
            )
        val bodyStr = bodyJson.toString()

        for (attempt in 1..4) {
            val req = Request.Builder()
                .url(baseUrl.trimEnd('/') + "/chat/completions")
                .header("Authorization", "Bearer $key")
                .post(bodyStr.toRequestBody("application/json".toMediaType()))
                .build()

            val resp = http.newCall(req).execute()
            val code = resp.code
            val wait = Api.retryDelayMs(resp, attempt)
            val text = resp.body?.string() ?: ""
            resp.close()

            when {
                code in 200..299 -> return parse(text, lines.size)
                code == 401 || code == 403 -> throw FatalApiError("مفتاح API غير صحيح أو لا يملك صلاحية")
                code == 429 || code in 500..599 -> {
                    if (attempt < 4) delay(wait)
                    else throw Exception("الخدمة مشغولة حالياً، أعد المحاولة بعد قليل")
                }
                else -> throw Exception("خطأ ($code): ${text.take(80)}")
            }
        }
        throw Exception("تعذّر الاتصال")
    }

    private fun parse(json: String, expected: Int): List<String> {
        val raw = JSONObject(json)
            .getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").optString("content", "").trim()
        if (raw.isEmpty()) throw Exception("رد فارغ من النموذج")
        val content = raw.removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        val arr = JSONObject(content).getJSONArray("translations")
        if (arr.length() != expected) throw Exception("عدد الأسطر المترجمة غير مطابق")
        val out = ArrayList<String>(expected)
        for (i in 0 until arr.length()) out.add(arr.optString(i, "").trim())
        return out
    }
}
